# FeatureCard
One capability: icon well, title, two-line description.

- `div.mp-feature` > `div.mp-feature__icon` (a Lucide icon, 22px, 1.75 stroke, in `accent-ink` on `accent-soft`) + `h3` + `p`.
- Title names the capability in plain words (3–4 words). Description says the outcome in one or two sentences — no adjectives like "powerful" or "seamless".
- Lay them in a 3-up grid (2-up tablet, 1-up phone) with 24px gaps. Never colour the left border.
