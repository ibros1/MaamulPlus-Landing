# StatTile
A money metric as the product shows it: uppercase label, big tabular figure, one-line note.

- `div.mp-stat` > `.mp-stat__label` (eyebrow) + `.mp-stat__value` (`figure` style; currency sign in a `small`) + `.mp-stat__note`.
- Credit owed and money out uses `--danger`; money in uses `--in`; everything else stays `heading`.
- Used only inside product mocks on the website; figures are sample data and must look like it (realistic, not round millions).
