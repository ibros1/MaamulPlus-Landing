# Button
Links and actions, in four variants; one primary per view.

- Markup: `<a|button class="mp-btn mp-btn--primary">Label</a>`. Sizes `mp-btn--sm` (36px), default (44px), `mp-btn--lg` (52px); shape `mp-btn--pill`; `mp-btn--block` fills its container.
- `mp-btn--primary` fills with `primary` + `on-primary` (navy on light, green-400 with navy text on dark). Use it for the one action that matters: **Book a demo**, **Request pricing**.
- `mp-btn--outline` is the secondary action beside a primary. `mp-btn--ghost` for nav-level actions such as **Sign in**.
- On `surface-inverse` (navy bands, the featured plan) use `mp-btn--green` for the main action and `mp-btn--on-inverse` for the second — never `mp-btn--primary`, which is navy-on-navy on light.
- A trailing arrow (`svg.mp-arrow`, Lucide `arrow-right`, 16px) is for forward-moving CTAs only and nudges 3px on hover.
- Labels: sentence case, verb first, 1–3 words. Never "Click here", never a price.
