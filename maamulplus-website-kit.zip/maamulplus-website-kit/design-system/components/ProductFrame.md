# ProductFrame
A browser window that holds a product screen — real screenshot or an HTML mock.

- `div.mp-frame` > `.mp-frame__bar` (three muted dots + `.mp-frame__url` in `mono`) + `.mp-frame__body`.
- `radius-lg`, `line` border and `shadow-lg` — the only place on the site with a large shadow.
- Show the URL as `app.maamulplus.com/<page>`. Put real product screens inside; never a stock photo.
