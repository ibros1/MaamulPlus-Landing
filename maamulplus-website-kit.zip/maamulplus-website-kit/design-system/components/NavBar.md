# NavBar
The sticky top bar: logo, five section links, Sign in and one CTA.

- `nav.mp-nav` > `a.mp-nav__logo` (the primary logo `MaamulPlus-Logo-v2.svg` at 30px tall; `MaamulPlus-Logo-v2-white.svg` on dark) + `ul.mp-nav__links` + `div.mp-nav__end`.
- Surface is translucent `surface` with a backdrop blur and a `line` hairline under it. Mark the current section with `aria-current`.
- Below 900px hide the links and show a menu button; keep the CTA.
