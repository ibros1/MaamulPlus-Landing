# Accordion
FAQ list built on native `<details>`.

- `div.mp-faq` > `details` > `summary` (question + empty `i` that draws the plus/minus) + `p` (answer).
- Questions are what a shop owner would actually ask, ending in "?". Answers start with Yes/No where possible, two sentences max.
- First item may start `open`. No nested accordions.
