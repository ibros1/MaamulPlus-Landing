# Badge
A small pill label for status, edition names and short facts.

- `mp-badge` is neutral (`brand-soft`); `mp-badge--green` uses `accent-soft` + `accent-ink`; add `mp-badge--dot` for a live/announcement dot; `mp-badge--inverse` on navy.
- Two to four words. Sentence case, no trailing period, no emoji.
- Not a button: never link a badge.
