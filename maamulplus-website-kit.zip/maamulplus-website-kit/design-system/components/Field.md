# Field
Label + control + optional hint for the demo / pricing request form.

- `div.mp-field` > `label` + `input.mp-input` | `select.mp-select` | `textarea.mp-textarea` + optional `span.mp-hint`.
- Borders use `line-strong` (3:1 on `surface`), focus a 2px `focus` ring. Height 44px, `radius-sm`.
- Labels are nouns in sentence case; placeholders show an example, never the instruction.
