# PlanCard
One edition in the pricing section — never a figure, always a request.

- `div.mp-plan` (add `--featured` for Enterprise, which sits on `surface-inverse`) > `.mp-plan__top` (name + badge) + `.mp-plan__for` + `.mp-plan__price` + `ul.mp-plan__list` + `.mp-plan__cta`.
- The name is "MaamulPlus" + edition in `span` (green). The price block says **Pricing on request** (Lite) or **Custom quote** (Enterprise) with one qualifying line. Never print a number.
- List items start with a Lucide `check` in `accent`; a `li.mp-plan__group` row introduces inherited features ("Everything in Lite, plus").
- CTA: Lite → `mp-btn--primary` "Request pricing"; Enterprise → `mp-btn--green` "Talk to sales".
