# SectionHeader
Eyebrow + title + lead that opens every website section.

- `div.mp-section-head` (add `--center` for centered sections) holding `p.mp-eyebrow`, `h2` (`h2` style, DM Sans 500) and an optional lead `p` (`body-lg`, `ink-muted`).
- Eyebrow: one or two words, uppercase via CSS, in `accent-ink`. Title: one short sentence ending in a period. Lead: at most two sentences.
- Keep it to 680px wide; never stack two headers.
