MaamulPlus is business-management software for traders in Somaliland — sales, stock, credit, payments and accounting in one place. It ships in two editions: **MaamulPlus Enterprise** (full double-entry accounting, multi-branch, sales agents) and **MaamulPlus Lite** (the essentials for small and medium businesses). This system styles the public website, maamulplus.com, and anything else that speaks for the brand.

## Content fundamentals

- **Language:** English for the website, in professional terms: say **credit** / **credit outstanding**, never "deyn". Local names stay as they are: **Zaad**, **eDahab**, **Sahal**, **SLSH**.
- **Voice:** a capable shopkeeper's accountant — calm, plain, specific. Say what the software does, not how amazing it is. Banned: "revolutionary", "seamless", "powerful", "unlock", "supercharge", "all-in-one solution".
- **Casing:** sentence case everywhere — headings, buttons, nav. Product names keep their case: MaamulPlus, MaamulPlus Enterprise, MaamulPlus Lite. Never "Maamul Plus" or "MAAMULPLUS".
- **Person:** speak to the owner as "you" / "your business"; the company is "we".
- **Headlines** are short declaratives with a period: "Every shilling, accounted for." Follow with at most two sentences.
- **The product's own copy is the reference voice** — quote it, mirror it:
  - "Everything the business did today, in one page."
  - "Where the money sits, and how it moved this month."
  - "Invoices that move stock and post to your books."
  - "Money in, money out, and where it stands."
- **Pricing:** never print a figure. Use **Pricing on request**, **Custom quote**, **Request pricing**, **Talk to sales**, **Book a demo**.
- **No emoji.** Numbers in copy use digits ("8 accounts", "3 branches").

## Visual foundations

### Colour
- The brand is two inks from the logo: `navy-900` and `green-500`. Navy carries structure (headings via `heading`, primary buttons via `primary`, the CTA band via `surface-inverse`); green is the "plus" — growth, money in, confirmation (`accent`, `accent-ink`).
- Build pages from the semantic tokens, not the raw scale: `bg`, `surface`, `surface-alt` for grounds; `heading`, `ink`, `ink-muted` for text; `line` for hairlines, `line-strong` for control borders.
- `green-500` is for graphics and text 24px+ only (3.1:1 on white). Green text below 24px is `accent-ink`.
- Money semantics match the app: credit owed / money out → `danger`; in → `accent-ink`; low stock → `warning`. Each always comes with a word, never colour alone.
- Alternate sections between `bg` and `surface-alt`; one `surface-inverse` band per page at most (the closing CTA), plus the featured Enterprise plan.
- Dark theme: navy deepens to `#060E22`, primary buttons turn `green-400` with navy labels, headings go white. Use the white logo there.

### Type
- **DM Sans** (`display` family) for headings and figures at weight **500** — never 700+. Tight tracking (−0.035em display, −0.025em `h2`). Styles: `display`, `h1`, `h2`, `h3`, `figure`.
- **Inter** (`sans` family) for everything you read: `body-lg`, `body`, `small`, `label`, `eyebrow`.
- `mono` (system monospace) only for invoice numbers, account codes and exchange rates inside product mocks (`code`).
- Money is always tabular (`font-variant-numeric: tabular-nums`) with the currency sign smaller and muted, as in the app.
- Every section opens with an `eyebrow` in `accent-ink` above its `h2`.
- Both families load from Google Fonts: DM Sans 400/500/600 (opsz 9..40), Inter 400/500/600.

### Space, radius, borders, shadow
- 4px base: `space-1` … `space-32`. Section padding `space-24` desktop / `space-16` phone; card padding `space-6`; plan cards `space-8`. Content max width 1200px with a 24px gutter (16px on phones).
- Radii from the brand tokens: `radius-sm` (inputs, small chips), `radius-md` (buttons, tiles), `radius-lg` (cards, plans, product frames, CTA band); `radius-pill` for badges and the nav CTA — it echoes the round stroke ends of the M.
- Borders do the work: 1px `line` hairlines on every card. `shadow-sm` at rest; `shadow-lg` only on product frames and floating metric chips in the hero.

### Imagery
- Real product screens only, inside a `ProductFrame` (`app.maamulplus.com/...`). Sample data looks real: Hargeisa business names, USD with SLSH rates, Zaad/eDahab accounts.
- No stock photos of handshakes, no 3D blobs, no blue-purple gradients. The only gradient allowed is a faint `accent` area fill under a chart line, as in the app.
- Background texture, when used, is a faint 32px grid of `line` hairlines on the hero — the same grid as the social posters.

### Motion and states
- 150–200ms ease on hover colour changes; CTA arrows slide 3px right on hover. Content fades up 12px once as it enters the viewport; respect `prefers-reduced-motion`.
- Focus: a solid 2px `focus` ring, 2px offset, on every link, button, field and summary (≥3:1 on every ground in both themes).

## Iconography
- **Lucide** (the icon set the app uses via shadcn/ui), inline SVG, 24px grid, stroke **1.75** at 20–22px, stroke 2 at 16px, round caps and joins, `currentColor`.
- Icons sit in a 44px `accent-soft` well on feature cards; plain `accent` for list checks.
- No emoji, no filled or duotone icon sets, no icons inside headings.

## Logo
- Use only the files in **Logos**. Primary lockup on light grounds, the white version on navy and the dark theme, the icon for square spaces. Never separate the M symbol from "aamulPlus", never recolour, stretch or add effects. Clear space = width of the green plus.

## Editions (how to talk about them)
- **MaamulPlus Lite** — for small and medium businesses: sales, purchases, products, customers, vendors, payments, expenses, accounts and the financial statements a small business needs. Simple language, no accounting jargon.
- **MaamulPlus Enterprise** — everything in Lite plus a full accounting module: double-entry bookkeeping, chart of accounts, journals and trial balance; sales agents and field sessions; multi-branch stock, transfers and adjustments; HR and payroll; roles and permissions; audit log; the AI assistant.
- Enterprise is the featured plan (`PlanCard --featured`). Lite is never described as "cheap" or "basic" — it is "focused".
