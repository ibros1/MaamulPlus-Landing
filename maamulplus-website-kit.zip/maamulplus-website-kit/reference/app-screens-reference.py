from icons import I

NAV = [
 ('Overview', [('Dashboard','grid'),('Assistant','sparkles')]),
 ('Sales', [('Sales dashboard','gauge'),('Sales','cart'),('Quotations','file'),('Sales returns','swap')]),
 ('Purchases', [('Purchases','truck'),('Purchase returns','swap')]),
 ('Inventory', [('Products','package'),('Stock','package'),('Transfers','swap'),('Adjustments','file')]),
 ('Parties', [('Customers','users'),('Vendors','store')]),
 ('Money', [('Finance dashboard','gauge'),('Payments','wallet'),('Sales agents','route'),('Expenses','receipt'),('Accounts','landmark')]),
 ('Accounting', [('Chart of accounts','book'),('Transactions','file')]),
 ('HR', [('HR dashboard','gauge'),('Employees','users'),('Payroll','banknote')]),
 ('Reports', [('Sales summary','cart'),('Cash flow','banknote'),('Income statement','file'),('Balance sheet','landmark')]),
]

def mac(url, inner, label, tall=False):
    host, _, path = url.partition('/')
    return f'''<div class="mac" role="img" aria-label="{label}">
<div class="mac-bar" aria-hidden="true"><div class="mac-lights"><i></i><i></i><i></i></div><div class="mac-nav">{I('chevl','2')}{I('chevr','2')}</div>
<div class="mac-url">{I('lock','2')}<span><b>{host}</b>/{path}</span></div><div class="mac-tools">{I('share','1.75')}{I('plus','1.75')}{I('copy','1.75')}</div></div>
<div class="ui-view{' ui-view--tall' if tall else ''}" aria-hidden="true">{inner}</div></div>'''

def shell(active, start_group, body, logo):
    nav = ''
    for gi, (g, items) in enumerate(NAV):
        if gi < start_group: continue
        nav += f'<div class="ui-g">{g}</div>' + ''.join(f'<div class="ui-i{" on" if n==active else ""}">{I(ic)}{n}</div>' for n, ic in items)
    return f'''<div class="ui"><aside class="ui-side"><div class="ui-logo">{logo}</div>
<div class="ui-biz"><b>HS</b><span>Hargeisa Spare Parts<small>Main Branch</small></span>{I('updown','2')}</div>
<div class="ui-navwrap"><div class="ui-nav">{nav}</div></div>
<div class="ui-user"><div class="ui-av">IM</div><span>Ibrahim Mohamed<small>Administrator</small></span></div></aside>
<div class="ui-main"><div class="ui-top"><div class="sq">{I('panel')}</div><div class="ui-search">{I('search','2')}Search customers, products, invoices…<kbd>⌘K</kbd></div>
<div class="ui-rate">1 USD = 11,000 SLSH</div><div class="ic">{I('lang')}</div><div class="ic">{I('sun')}</div><div class="ic dot">{I('bell')}</div><div class="ui-av">IM</div></div>
<div class="ui-body">{body}</div><div class="ufoot"><span>© 2026 Hargeisa Spare Parts · MaamulPlus</span><span>All branches · ⌘K to search</span></div></div></div>'''

def money(v, cls=''):
    return f'<div class="uv {cls}"><small>$</small>{v}</div>'

def card(label, v, note='', icon=None, wcls='', vcls=''):
    w = f'<div class="uw {wcls}">{I(icon)}</div>' if icon else ''
    n = f'<div class="un">{note}</div>' if note else ''
    return f'<div class="ucard{" ico" if icon else ""}">{w}<div><div class="ul">{label}</div>{money(v, vcls) if v[0].isdigit() and not v.isdigit() else f"<div class=uv>{v}</div>"}{n}</div></div>'

# ---------- Dashboard (hero) ----------
def dashboard():
    pts = [8,6,7,4,9,12,10,7,14,16,11,13,18,21]
    W,H=560,160; mx=22
    xs=[i*(W/(len(pts)-1)) for i in range(len(pts))]; ys=[H-8-(p/mx)*(H-24) for p in pts]
    d='M'+' L'.join(f'{x:.1f} {y:.1f}' for x,y in zip(xs,ys))
    body=f'''<div class="ui-head"><div><small>Friday, October 23</small><h4>Welcome back, Ibrahim</h4><p>Everything the business did today, in one page.</p></div><div class="act"><span class="ub">{I('refresh','2')}Refresh</span><span class="ub go">{I('plus','2.25')}New sale</span></div></div>
<div class="upanel" style="display:grid;grid-template-columns:330px 1fr"><div style="padding:18px 20px;border-right:1px solid var(--line)"><div class="ul">Takings today</div><div class="un" style="margin-top:8px">14 invoices written today</div><div class="uv xl"><small>$</small>1,284.50</div><div class="un"><span class="pill ok" style="margin-right:6px">+12.4%</span>on last Friday</div></div>
<div class="uchart" style="padding:14px 16px 6px"><svg viewBox="0 0 {W} {H}" width="100%" height="150" preserveAspectRatio="none"><line class="gl" x1="0" x2="{W}" y1="40" y2="40"/><line class="gl" x1="0" x2="{W}" y1="80" y2="80"/><line class="gl" x1="0" x2="{W}" y1="120" y2="120"/><path d="{d} L{W} {H} L0 {H}Z" style="fill:var(--accent);opacity:.1"/><path d="{d}" style="fill:none;stroke:var(--accent);stroke-width:2.2;vector-effect:non-scaling-stroke"/><circle cx="{xs[-1]-3:.1f}" cy="{ys[-1]:.1f}" r="4" style="fill:var(--accent)"/></svg></div></div>
<div class="ucards" style="grid-template-columns:repeat(4,1fr)">{card('This month','24,650.06','on 128 invoices','cart')}{card('Credit outstanding','1,284.36','9 invoices still owing','receipt','red','red')}{card('Stock value','17,979.10','4 lines running low','package','navy')}{card('Cash on hand','7,436.03','across cash, bank and mobile money','wallet')}</div>
<div class="ugrid" style="grid-template-columns:1.5fr 1fr"><div class="upanel"><div class="upanel-h"><div><div class="ul">Latest</div><b>Recent sales</b></div><a>View all</a></div>
<div class="urow"><span><b style="font-weight:500">INV-000214</b><small>Abdi Ahmed · credit</small></span><span class="pill part">Partly paid</span><span class="r">$950.00</span></div>
<div class="urow"><span><b style="font-weight:500">INV-000213</b><small>Walk-in · Zaad</small></span><span class="pill ok">Paid</span><span class="r">$186.00</span></div>
<div class="urow"><span><b style="font-weight:500">INV-000212</b><small>Omar Trading · bank</small></span><span class="pill ok">Paid</span><span class="r">$1,420.00</span></div></div>
<div class="upanel"><div class="upanel-h"><div><div class="ul">Get on with it</div><b>Quick actions</b></div></div>
<div class="urow"><span style="display:flex;gap:8px;align-items:center">{I('receipt')}Write a sale</span></div><div class="urow"><span style="display:flex;gap:8px;align-items:center">{I('truck')}Record a purchase</span></div><div class="urow"><span style="display:flex;gap:8px;align-items:center">{I('wallet')}Take a payment</span></div></div></div>'''
    return body

# ---------- Sales ----------
def sales():
    rows=[('INV-000214','Abdi Ahmed','Main Branch','Ibrahim M.','Oct 23, 2026','03:21 PM','950.00','520.00','part','Partly paid'),
          ('INV-000213','Walk-in','Main Branch','Khadar F.','Oct 23, 2026','02:48 PM','186.00','0.00','ok','Paid'),
          ('INV-000212','Omar Trading','Waaheen Branch','Ibrahim M.','Oct 23, 2026','11:05 AM','1,420.00','0.00','ok','Paid'),
          ('INV-000211','Jamac Ahmed','Main Branch','Khadar F.','Oct 22, 2026','05:12 PM','207.18','207.18','due','Credit'),
          ('INV-000210','Walk-in','Waaheen Branch','Sahra A.','Oct 22, 2026','01:40 PM','64.50','0.00','ok','Paid'),
          ('INV-000209','Hodan Motors','Main Branch','Ibrahim M.','Oct 22, 2026','10:02 AM','3,800.00','0.00','ok','Paid'),
          ('INV-000208','Abdi Ahmed','Main Branch','Khadar F.','Oct 21, 2026','04:30 PM','910.00','0.00','ok','Paid'),
          ('INV-000207','Ayaan Garage','Waaheen Branch','Sahra A.','Oct 21, 2026','09:15 AM','1,250.00','300.00','part','Partly paid')]
    tr=''.join(f'<tr><td class="m">{n}</td><td class="{"mu" if c=="Walk-in" else ""}">{c}</td><td><span class="meta">{I("building")}{b}</span></td><td><span class="meta">{I("user")}{s}</span></td><td>{d}<span class="sub">{t}</span></td><td class="r">${tot}</td><td class="r {"red" if bal!="0.00" else "mu"}">${bal}</td><td><span class="pill {pc}">{pl}</span></td><td><span class="pill info">Confirmed</span></td></tr>' for n,c,b,s,d,t,tot,bal,pc,pl in rows)
    return f'''<div class="ui-head"><div><h4>Sales</h4><p>Invoices that move stock and post to your books.</p></div><div class="act"><span class="ub">{I('download','2')}Export</span><span class="ub go">{I('plus','2.25')}New sale</span></div></div>
<div class="ucards" style="grid-template-columns:repeat(4,1fr)">{card('Invoices','128','this month','receipt')}{card('Revenue','24,650.06','this month','trend')}{card('Outstanding','1,284.36','on 9 invoices','wallet','amber','red')}{card('Today','14','$1,284.50 taken','clock','navy')}</div>
<div class="ufilters"><div class="uf"><label>Sale no.</label><div class="uin ph" style="width:200px">{I('search','2')}INV-0001…</div></div><div class="uf"><label>Status</label><div class="uin">All statuses{I('chev','2','chev')}</div></div><div class="uf"><label>Payment</label><div class="uin">All payments{I('chev','2','chev')}</div></div><div class="uf"><label>Period</label><div class="uin">{I('cal','2')}This month{I('chev','2','chev')}</div></div><div class="end"><span class="ub go-ink">{I('search','2')}Search</span><span class="ub">{I('refresh','2')}Reset</span></div></div>
<div class="utable"><table><thead><tr><th>Number</th><th>Customer</th><th>Branch</th><th>Sold by</th><th>Date</th><th class="r">Total</th><th class="r">Balance</th><th>Payment</th><th>Status</th></tr></thead><tbody>{tr}</tbody></table></div>'''

# ---------- Customer & credit ----------
def customer():
    rows=[('INV-000211','Oct 22, 2026','207.18','0.00','207.18','due','Unpaid'),
          ('INV-000196','Oct 14, 2026','480.00','480.00','0.00','ok','Paid'),
          ('PAY-000088','Oct 12, 2026','—','200.00','—','info','Payment · Zaad'),
          ('INV-000181','Oct 05, 2026','320.00','320.00','0.00','ok','Paid'),
          ('INV-000170','Sep 28, 2026','150.00','150.00','0.00','ok','Paid'),
          ('INV-000152','Sep 19, 2026','612.40','612.40','0.00','ok','Paid'),
          ('INV-000140','Sep 11, 2026','95.00','95.00','0.00','ok','Paid')]
    tr=''.join(f'<tr><td class="m">{n}</td><td>{d}</td><td class="r">{"$"+t if t!="—" else "—"}</td><td class="r green">${p}</td><td class="r {"red" if b not in ("0.00","—") else "mu"}">{"$"+b if b!="—" else "—"}</td><td><span class="pill {pc}">{pl}</span></td></tr>' for n,d,t,p,b,pc,pl in rows)
    return f'''<div style="font-size:12px;color:var(--ink-muted);display:flex;align-items:center;gap:6px">{I('chevl','2')}Back to customers</div>
<div class="uprof"><div class="big">JA</div><div><h4>Jamac Ahmed <span class="pill info">Retail</span><span class="pill ok">Active</span></h4><p><span>{I('tel')}+252 63 441 2290</span><span>{I('mail')}jamac.ahmed@hargeisa.so</span><span>{I('building')}Main Branch</span></p></div>
<div style="margin-left:auto;display:flex;gap:8px"><span class="ub go">{I('wallet','2')}Receive payment</span><span class="ub">{I('printer','2')}Print statement</span><span class="ub">{I('pencil','2')}Edit</span></div></div>
<div class="ucards" style="grid-template-columns:repeat(4,1fr)">{card('Balance owed','207.18','1 invoice open','receipt','red','red')}{card('Paid to date','1,857.40','since Jan 2026','wallet')}{card('Credit limit','400.00','$192.82 still available','shield','navy')}{card('Invoices','12','avg. $281.90','file','navy')}</div>
<div class="ugrid" style="grid-template-columns:1.9fr 1fr"><div class="utable"><table><thead><tr><th>Document</th><th>Date</th><th class="r">Total</th><th class="r">Paid</th><th class="r">Balance</th><th>Status</th></tr></thead><tbody>{tr}</tbody></table></div>
<div class="upanel"><div class="upanel-h"><div><div class="ul">Credit</div><b>Limit used</b></div><span class="pill part">52%</span></div><div style="padding:4px 16px 16px"><div class="ubar" style="height:8px"><i style="width:52%;background:var(--warning)"></i></div><div class="un" style="margin-top:8px">$207.18 of $400.00</div></div>
<div class="urow"><span>Opening balance<small>Recorded Jan 1, 2026</small></span><span class="r">$0.00</span></div><div class="urow"><span>Last payment<small>Oct 12 · Zaad</small></span><span class="r">$200.00</span></div><div class="urow"><span>Oldest unpaid<small>INV-000211</small></span><span class="r red">1 day</span></div></div></div>'''

# ---------- Finance ----------
def finance():
    accts=[('Cash — Main Branch','1010','Cash',62,'4,612.00'),('Main cash drawer','1020','Cash',8,'596.03'),('Premier Bank','1031','Bank',14,'1,040.00'),('Salaam Bank','1032','Bank',6,'420.00'),('Zaad Merchant','1041','Mobile money',7,'512.00'),('eDahab Merchant','1042','Mobile money',3,'256.00')]
    tr=''.join(f'<tr><td>{n} <span class="mu" style="font:400 11.5px var(--font-mono);margin-left:4px">{c}</span></td><td><span class="pill out">{k}</span></td><td><div class="ubar"><i style="width:{s}%"></i></div></td><td class="r">${b}</td></tr>' for n,c,k,s,b in accts)
    bars=[(3,1),(5,2),(2,1),(6,3),(4,2),(7,2),(5,4),(8,3),(6,2),(9,3),(7,5),(10,4)]
    svg='';bw=12;gap=34
    for i,(a,b) in enumerate(bars):
        x=20+i*gap; svg+=f'<rect class="in" x="{x}" y="{130-a*11}" width="{bw}" height="{a*11}" rx="3"/><rect class="out" x="{x+bw+2}" y="{130-b*11}" width="{bw}" height="{b*11}" rx="3"/>'
    return f'''<div class="ui-head"><div><small>Friday, October 23</small><h4>Finance</h4><p>Where the money sits, and how it moved this month.</p></div><div class="act"><span class="ub">{I('file','2')}Cash flow report</span><span class="ub">{I('swap','2')}Transfer</span></div></div>
<div class="upanel" style="display:grid;grid-template-columns:330px 1fr"><div style="padding:18px 20px;border-right:1px solid var(--line)"><div class="ul">Cash position</div><div class="un" style="margin-top:8px">Held across 6 accounts</div><div class="uv xl"><small>$</small>7,436.03</div><div class="un">42 receipts and 17 payments this month</div></div>
<div class="uchart" style="padding:14px 18px 8px"><div style="display:flex;justify-content:flex-end" class="uleg"><span><i></i>Money in</span><span><i class="r"></i>Money out</span></div><svg viewBox="0 0 440 150" width="100%" height="140" preserveAspectRatio="none"><line class="gl" x1="0" x2="440" y1="42" y2="42"/><line class="gl" x1="0" x2="440" y1="86" y2="86"/><line class="ax" x1="0" x2="440" y1="130.5" y2="130.5"/>{svg}<text x="20" y="146">Oct 1</text><text x="190" y="146">Oct 12</text><text x="395" y="146">Oct 23</text></svg></div></div>
<div class="ucards" style="grid-template-columns:repeat(4,1fr)"><div class="ucard"><div class="ul">In this month</div>{money('9,820.40','green')}</div><div class="ucard"><div class="ul">Out this month</div>{money('4,135.10','red')}</div><div class="ucard"><div class="ul">Net movement</div>{money('5,685.30','green')}</div><div class="ucard"><div class="ul">Expenses</div>{money('640.00','red')}</div></div>
<div class="ugrid" style="grid-template-columns:1.7fr 1fr"><div class="utable"><table><thead><tr><th>Account</th><th>Kind</th><th>Share</th><th class="r">Balance</th></tr></thead><tbody>{tr}</tbody></table></div>
<div class="upanel"><div class="upanel-h"><div><div class="ul">Owed</div><b>Both directions</b></div></div><div class="urow"><span>Customers owe us<small>9 unpaid invoices</small></span><span class="r red">$1,284.36</span></div><div class="urow"><span>We owe suppliers<small>3 unpaid bills</small></span><span class="r">$2,310.00</span></div><div class="urow"><span>Staff advances<small>2 open</small></span><span class="r">$300.00</span></div></div></div>'''

# ---------- Cash flow report ----------
def cashflow():
    src=[('Sales (cash)',5200.40,'in'),('Customer payments',3620,'in'),('Deposits',1000,'in'),('Purchases (cash)',-345.10,'out'),('Supplier payments',-300,'out'),('Expenses',-640,'out'),('Payroll',-2850,'out')]
    mx=5600; cx=470; sc=360/mx; svg=''
    for i,(n,v,c) in enumerate(src):
        y=10+i*26; w=abs(v)*sc; x=cx if v>0 else cx-w
        svg+=f'<text x="{cx-380}" y="{y+13}" text-anchor="start">{n}</text><rect class="{c}" x="{x:.1f}" y="{y}" width="{w:.1f}" height="16" rx="3"/><text x="{(x+w+6) if v>0 else (x-6):.1f}" y="{y+12}" text-anchor="{"start" if v>0 else "end"}">{abs(v):,.0f}</text>'
    svg+=f'<line class="ax" x1="{cx}" x2="{cx}" y1="4" y2="190"/>'
    acc=[('1010 · Cash — Main Branch','1,100.00','6,400.00','2,888.00','4,612.00'),('1031 · Premier Bank','300.00','1,900.00','1,160.00','1,040.00'),('1041 · Zaad Merchant','100.00','980.00','568.00','512.00')]
    tr=''.join(f'<tr><td>{a}</td><td class="r green">${i}</td><td class="r red">${x}</td><td class="r" style="font-weight:600;color:var(--heading)">${c}</td></tr>' for a,o,i,x,c in acc)
    return f'''<div class="ui-head"><div><h4>{I('banknote','2')}Cash flow</h4><p>Money in, money out, and where it stands, classified by what brought money in or took it out.</p></div><div class="act" style="text-align:right;font-size:11.5px;color:var(--ink-muted);display:block"><div style="display:flex;gap:6px;align-items:center;justify-content:flex-end;color:var(--heading);font-weight:500;font-size:12.5px">{I('building','2')}All branches</div>Generated Oct 23, 2026, 4:12 PM</div></div>
<div class="ufilters"><div class="uf"><label>Period</label><div class="uin">{I('cal','2')}This month{I('chev','2','chev')}</div></div><div class="uf"><label>From</label><div class="uin">10/01/2026</div></div><div class="uf"><label>To</label><div class="uin">10/23/2026</div></div><div class="uf"><label>Branch</label><div class="uin">{I('building','2')}All branches{I('chev','2','chev')}</div></div><div class="end"><span class="ub">{I('refresh','2')}Refresh</span><span class="ub">{I('download','2')}CSV</span><span class="ub">{I('file','2')}PDF</span></div></div>
<div class="ucards" style="grid-template-columns:repeat(4,1fr)">{card('Opening','1,750.73','Oct 1, 2026','wallet','navy')}{card('Cash in','9,820.40','excludes transfers','arrowin','','green')}{card('Cash out','4,135.10','excludes transfers','arrowout','red','red')}{card('Closing','7,436.03','what is in the accounts now','banknote','','')}</div>
<div class="ueq"><b>$1,750.73</b> opening + <span class="g">$9,820.40</span> in − <span class="d">$4,135.10</span> out = <b>$7,436.03</b> closing</div>
<div class="ugrid" style="grid-template-columns:1fr 1fr"><div class="upanel"><div class="upanel-h"><b>Cash movement</b><div class="useg"><span class="on">By source</span><span>Waterfall</span><span>Daily</span></div></div><div class="uchart" style="padding:0 16px 10px"><svg viewBox="0 0 560 196" width="100%" height="196">{svg}</svg></div></div>
<div class="utable" style="align-self:start"><table><thead><tr><th>Top accounts</th><th class="r">In</th><th class="r">Out</th><th class="r">Closing</th></tr></thead><tbody>{tr}</tbody></table></div></div>'''

# ---------- People & payroll ----------
def people():
    dept=[('Sales',4,100),('Store',3,75),('Delivery',2,50),('Finance',1,25)]
    dp=''.join(f'<div style="display:grid;grid-template-columns:80px 1fr 20px;gap:12px;align-items:center;padding:7px 0;font-size:12.5px"><span>{n}</span><div class="ubar" style="height:8px"><i style="width:{w}%"></i></div><span class="r" style="text-align:right">{c}</span></div>' for n,c,w in dept)
    emp=[('Khadar Farah','Cashier','Main Branch','350.00','ok','Paid'),('Sahra Aden','Sales','Waaheen Branch','380.00','ok','Paid'),('Mohamed Yusuf','Store keeper','Main Branch','320.00','part','Advance'),('Ayaan Ali','Accountant','Main Branch','520.00','ok','Paid'),('Liban Hassan','Driver','Main Branch','280.00','info','Pending')]
    tr=''.join(f'<tr><td><span style="display:inline-flex;align-items:center;gap:9px"><span class="ui-av" style="width:26px;height:26px;font-size:10px;background:var(--brand-soft);color:var(--heading)">{n.split()[0][0]}{n.split()[1][0]}</span>{n}</span></td><td>{r}</td><td><span class="meta">{I("building")}{b}</span></td><td class="r">${s}</td><td><span class="pill {pc}">{pl}</span></td></tr>' for n,r,b,s,pc,pl in emp)
    return f'''<div class="ui-head"><div><small>Friday, October 23</small><h4>People</h4><p>Who is on the books, what they cost, and where payroll stands.</p></div><div class="act"><span class="ub go">{I('banknote','2')}Run payroll</span><span class="ub">{I('refresh','2')}Refresh</span></div></div>
<div class="upanel" style="display:grid;grid-template-columns:330px 1fr"><div style="padding:18px 20px;border-right:1px solid var(--line)"><div class="ul">Monthly salary bill</div><div class="un" style="margin-top:8px">10 active on the books</div><div class="uv xl"><small>$</small>3,450.00</div><div class="un">1 new hire in the last 30 days</div></div><div style="padding:16px 22px"><div class="ul" style="margin-bottom:6px">Headcount by department</div>{dp}</div></div>
<div class="ucards" style="grid-template-columns:repeat(4,1fr)"><div class="ucard"><div class="ul">Active staff</div><div class="uv">10</div></div><div class="ucard"><div class="ul">Paid this month</div>{money('2,850.00')}</div><div class="ucard"><div class="ul">Deductions</div>{money('120.00','red')}</div><div class="ucard"><div class="ul">Advances owed</div>{money('300.00')}</div></div>
<div class="utable"><table><thead><tr><th>Employee</th><th>Role</th><th>Branch</th><th class="r">Salary</th><th>October</th></tr></thead><tbody>{tr}</tbody></table></div>'''

SCREENS = {
 'dashboard': ('Dashboard', 0, dashboard, 'app.maamulplus.com/dashboard'),
 'sales': ('Sales', 1, sales, 'app.maamulplus.com/sales'),
 'customer': ('Customers', 3, customer, 'app.maamulplus.com/customers/jamac-ahmed'),
 'finance': ('Finance dashboard', 4, finance, 'app.maamulplus.com/finance'),
 'cashflow': ('Cash flow', 6, cashflow, 'app.maamulplus.com/reports/cash-flow'),
 'people': ('HR dashboard', 5, people, 'app.maamulplus.com/hr'),
}

def render(key, logo, label):
    active, start, fn, url = SCREENS[key]
    return mac(url, shell(active, start, fn(), logo), label)
